from conf.SharepointConf import SharepointConf
from conf.FileConf import FileConf
from conf.OracleConf import OracleConf
from conf.InputConf import InputConf
from conf.OutputConf import OutputConf

from conf.AppConf import AppConf

import configparser


def load_app_config(config_path):
    try:
        conf = configparser.ConfigParser()
        conf.read(config_path)
        print(conf)

        app_conf = get_app_conf(load_input_conf(conf), load_output_conf(conf))

        return app_conf

    except Exception as e:
        raise e


def get_app_conf(input_conf, output_conf):
    return  AppConf(input_conf, output_conf)


def load_input_conf(config):
    source = config['INPUT']['source']
    input_temp_path = config['INPUT']['input_temp_path']

    share_point_conf = SharepointConf(config['INPUT']['SHAREPOINT']['url'],
                                      config['INPUT']['SHAREPOINT']['file_format'],
                                      config['INPUT']['SHAREPOINT']['excel_all_sheets'],
                                      config['INPUT']['SHAREPOINT']['excel_required_sheets'],
                                      config['INPUT']['SHAREPOINT']['header_fields'],
                                      config['INPUT']['SHAREPOINT']['user_name'],
                                      config['INPUT']['SHAREPOINT']['password'])

    file_conf = FileConf(config['INPUT']['FILE']['path'],
                         config['INPUT']['FILE']['file_format'],
                         config['INPUT']['FILE']['excel_all_sheets'],
                         config['INPUT']['FILE']['excel_required_sheets'],
                         config['INPUT']['FILE']['header_fields'])

    return InputConf(source, input_temp_path, share_point_conf, file_conf)


def load_output_conf(config):
    target = config['OUTPUT']['target']
    oracle_conf = OracleConf(config['OUTPUT']['ORACLE']['host'],
                             config['INPUT']['ORACLE']['port'],
                             config['INPUT']['ORACLE']['service_name'],
                             config['INPUT']['ORACLE']['user_name'],
                             config['INPUT']['ORACLE']['password'],
                             config['INPUT']['ORACLE']['table_name'])

    output_file_conf = FileConf(config['INPUT']['FILE']['path'],
                         config['INPUT']['FILE']['file_format'],
                         config['INPUT']['FILE']['excel_all_sheets'],
                         config['INPUT']['FILE']['excel_required_sheets'],
                         config['INPUT']['FILE']['header_fields'])

    return OutputConf(target, oracle_conf, output_file_conf)

