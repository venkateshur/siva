class OutputConf(object):
    def __init__(self, target, oracle_conf, output_file_conf):
        self.target = target
        self.oracle_conf = oracle_conf
        self.output_file_conf = output_file_conf