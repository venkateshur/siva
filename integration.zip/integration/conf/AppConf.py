class AppConf(object):
    def __init__(self, input_conf, output_conf):
        self.input_conf = input_conf
        self.output_conf = output_conf
