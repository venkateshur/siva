class InputConf(object):
    def __init__(self, source, share_point_conf, input_temp_path, input_file_conf):
        self.source = source
        self.share_point_conf = share_point_conf
        self.input_temp_path = input_temp_path
        self.input_source_conf = input_file_conf

