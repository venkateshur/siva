import cx_Oracle


def load_into_oracle(data, oracle_conf):
    con = cx_Oracle.connect(oracle_conf.hos)
    #cur = con.cursor()
    data.toSql(oracle_conf.table_name, con)