
from model.read.Reader import down_file_from_share_point
from model.read.Reader import csv_reader
from model.read.Reader import excel_reader


def main_processor(app_conf):
    if app_conf.input_conf.source == "SHAREPOINT":
        response = down_file_from_share_point(app_conf.input_conf.sharepoint_conf.url,
                                   app_conf.input_conf.sharepoint_conf.file,
                                   app_conf.input_conf.input_temp_path,
                                   app_conf.input_conf.sharepoint_conf.user_name,
                                   app_conf.input_conf.sharepoint_conf.password)

    elif app_conf.input_conf.source == "UNIX":
        if app_conf.input_conf.file_conf.file_format == "CSV":
            return csv_processor(app_conf.input_conf.path,
                                 app_conf.input_conf.fields,
                                 app_conf.input_conf.delimiter,
                                 app_conf.input_conf.header)

        elif app_conf.input_conf.file_conf.file_format == "EXCEL":
            return excel_processor(app_conf.input_conf.path,
                                 app_conf.input_conf.all_sheets_required,
                                 app_conf.input_conf.required_sheets,
                                 app_conf.input_conf.header)
        else:
            raise Exception("Invalid File Format")

    raise Exception("Invalid Source Type")


def csv_processor(path, required_fields, delimiter, header):
    return csv_reader(path, required_fields, delimiter, header)


def excel_processor(path, all_sheets_required, required_sheets, header):
    if all_sheets_required:
        return excel_reader(path, 0, header)
    else:
        return excel_reader(path, required_sheets, header)
